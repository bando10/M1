**Instruction l'utilisation de l'application**

1-Configuration : 
    Pour pourvoir lancer et éxecuter le programme nous avons utilisé Java 11 et le compilateur 1.8

2-Execution:
    -Ouvrir le projet TP1 avec IntelliJ.
    -Exécuter d'abord server.Server.java
    -Exécuter client.Client.java




